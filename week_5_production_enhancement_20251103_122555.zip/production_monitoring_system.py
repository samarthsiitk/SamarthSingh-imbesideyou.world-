# ===============================
# WEEK 5: PRODUCTION ENHANCEMENT & MONITORING
# ===============================

import json
import time
import psutil
import logging
import threading
import queue
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
import sqlite3
import statistics

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class SystemMetrics:
    """System performance metrics"""
    timestamp: str
    cpu_percent: float
    memory_usage_mb: float
    request_count: int
    average_response_time: float
    success_rate: float
    error_count: int
    active_connections: int

@dataclass
class RequestMetrics:
    """Individual request metrics"""
    timestamp: str
    request_id: str
    research_content_length: int
    workflow_type: str
    processing_time: float
    quality_score: int
    code_length: int
    success: bool
    error_message: Optional[str] = None

class MetricsCollector:
    """Advanced metrics collection and analysis"""
    
    def __init__(self, db_path: str = "production_metrics.db"):
        self.db_path = db_path
        self.request_queue = queue.Queue()
        self.system_metrics = []
        self.request_metrics = []
        self._init_database()
        self._start_background_tasks()
    
    def _init_database(self):
        """Initialize SQLite database for metrics storage"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create tables
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS system_metrics (
                timestamp TEXT PRIMARY KEY,
                cpu_percent REAL,
                memory_usage_mb REAL,
                request_count INTEGER,
                average_response_time REAL,
                success_rate REAL,
                error_count INTEGER,
                active_connections INTEGER
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS request_metrics (
                timestamp TEXT,
                request_id TEXT PRIMARY KEY,
                research_content_length INTEGER,
                workflow_type TEXT,
                processing_time REAL,
                quality_score INTEGER,
                code_length INTEGER,
                success BOOLEAN,
                error_message TEXT
            )
        """)
        
        conn.commit()
        conn.close()
        logger.info("✅ Metrics database initialized")
    
    def log_request(self, metrics: RequestMetrics):
        """Log a request for metrics collection"""
        self.request_queue.put(metrics)
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        """Get data for monitoring dashboard"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT * FROM system_metrics ORDER BY timestamp DESC LIMIT 1
        """)
        latest_system = cursor.fetchone()
        
        return {
            "current_status": {
                "cpu_percent": latest_system[1] if latest_system else 0,
                "memory_usage_mb": latest_system[2] if latest_system else 0,
                "success_rate": latest_system[5] if latest_system else 1.0,
                "active_requests": latest_system[7] if latest_system else 0
            }
        }

if __name__ == "__main__":
    collector = MetricsCollector()
    print("✅ Production monitoring system initialized")