# API Documentation

## ResearchToCodeAgent Class

### Main Methods

#### `__init__(model_path='./trained_model')`
Initialize the research-to-code agent.

#### `generate_code(research_content, workflow_type='advanced')`
Generate code from research content.

**Returns:**
```{
    'generated_code': str,      # Generated Python code
    'quality_score': int,       # Quality (0-100)
    'success': bool,           # Generation success
}
```

---
*API Documentation Version: 1.0*
*Last Updated: 2025-11-03*
