#!/bin/bash
echo "🚀 Installing Research-to-Code AI Agent..."

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found. Please install Python 3.8+"
    exit 1
fi

# Create virtual environment
python3 -m venv research_env
source research_env/bin/activate

# Install dependencies
pip install torch numpy pandas matplotlib scikit-learn

echo "✅ Installation completed!"
echo "Run: python research_to_code_agent.py"
